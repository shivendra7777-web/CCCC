import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Zap, Pickaxe, Gamepad2, Trophy, Wallet, 
  Copy, Share2, ArrowUpDown, 
  Clock, AlertTriangle, ChevronDown, ChevronUp, Infinity
} from 'lucide-react';

const formatTMC = (n) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const formatTON = (n) => n.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 });

export default function App() {
  const [activeTab, setActiveTab] = useState('mine');
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('tonmine_user');
    const base = {
      tmcBalance: 1247.50, totalMined: 748.50, totalWagered: 450.00,
      totalWon: 374.20, totalLost: 200.00, miningRate: 0.5, miningLevel: 1,
      energy: 100, maxEnergy: 100, lastTapAt: null, lastDailyTapAt: 0,
      lastActiveAt: Date.now(), lastEnergyRegen: Date.now(),
      claimStreak: 3, lastClaimAt: Date.now() - 86400000,
      referralCode: 'ABC123', referredBy: null,
      tonWalletAddress: null, username: 'TonMiner', totalMinedEver: 1248.50,
    };
    return saved ? { ...base, ...JSON.parse(saved) } : base;
  });

  const [transactions, setTransactions] = useState([
    { id: 1, type: 'crash_win', amount: 234.50, direction: 'credit', created_at: Date.now() - 120000, note: 'Cashed @ 2.45×' },
    { id: 2, type: 'bet_debit', amount: 50.00, direction: 'debit', created_at: Date.now() - 300000, note: 'Rolled 43 < 50' },
    { id: 3, type: 'mining_passive', amount: 12.34, direction: 'credit', created_at: Date.now() - 3600000, note: 'Passive mining' },
    { id: 4, type: 'deposit', amount: 1000.00, direction: 'credit', created_at: Date.now() - 10800000, ton_amount: 1.0, note: 'TON Deposit' },
  ]);

  const [floatingTexts, setFloatingTexts] = useState([]);
  const [liveBets, setLiveBets] = useState([
    { id: 1, username: 'CryptoKing', amount: 50, game: 'Crash', result: 'win', multiplier: 2.10, profit: 55 },
    { id: 2, username: 'Anonymous', amount: 100, game: 'Dice', result: 'lose', profit: -100 },
    { id: 3, username: 'TonWhale', amount: 500, game: 'Limbo', result: 'win', multiplier: 5.6, profit: 2300 },
  ]);

  // ===== CRASH GAME STATE =====
  const [crashDisplay, setCrashDisplay] = useState({
    gameState: 'betting', multiplier: 1.0, displayMultiplier: 1.0,
    crashPoint: null, timeLeft: 5, roundNumber: 1,
    chartPoints: [{ t: 0, m: 1.0 }], history: [2.45, 1.12, 5.67, 1.89, 3.21, 1.05, 8.90, 2.34, 1.45, 6.78],
    screenShake: false, particles: [], roundBets: [],
    serverSeedHash: 'a3f8c2d1...', rocketRotation: -45,
  });
  const [crashUserBet, setCrashUserBet] = useState(null);
  const [crashUserCashed, setCrashUserCashed] = useState(false);
  const [crashAutoCashout, setCrashAutoCashout] = useState('');
  const [crashBetAmount, setCrashBetAmount] = useState('50');
  const [crashAutoBet, setCrashAutoBet] = useState(false);
  const [showAutoBetSettings, setShowAutoBetSettings] = useState(false);
  const [autoBetSettings, setAutoBetSettings] = useState({
    baseAmount: 50, onWin: { action: 'reset', value: 0 },
    onLoss: { action: 'increase', value: 100 },
    stopOnWin: 0, stopOnLoss: 0, maxBet: 10000, rounds: 0,
  });
  const [autoBetStats, setAutoBetStats] = useState({ wins: 0, losses: 0, currentBet: 50, roundsLeft: 0 });

  const gameRef = useRef({
    gameState: 'betting', multiplier: 1.0, crashPoint: null,
    elapsed: 0, chartPoints: [{ t: 0, m: 1.0 }], particles: [],
    roundBets: [], roundNumber: 1, screenShake: false,
    serverSeedHash: 'a3f8c2d1...', rocketRotation: -45,
    history: [2.45, 1.12, 5.67, 1.89, 3.21, 1.05, 8.90, 2.34, 1.45, 6.78],
  });
  const userBetRef = useRef(null);
  const userCashedRef = useRef(false);
  const autoCashoutRef = useRef('');
  const autoBetRef = useRef(false);
  const autoBetSettingsRef = useRef(autoBetSettings);
  const autoBetStatsRef = useRef(autoBetStats);
  const betAmountRef = useRef(50);
  const userRef = useRef(user);
  const timerRef = useRef(null);
  const lastDisplayUpdateRef = useRef(0);

  useEffect(() => { userBetRef.current = crashUserBet; }, [crashUserBet]);
  useEffect(() => { userCashedRef.current = crashUserCashed; }, [crashUserCashed]);
  useEffect(() => { autoCashoutRef.current = crashAutoCashout; }, [crashAutoCashout]);
  useEffect(() => { autoBetRef.current = crashAutoBet; }, [crashAutoBet]);
  useEffect(() => { autoBetSettingsRef.current = autoBetSettings; }, [autoBetSettings]);
  useEffect(() => { autoBetStatsRef.current = autoBetStats; }, [autoBetStats]);
  useEffect(() => { betAmountRef.current = parseFloat(crashBetAmount) || 0; }, [crashBetAmount]);
  useEffect(() => { userRef.current = user; }, [user]);

  // FIXED: updateDisplay now handles crash state properly — no smoothing when crashed
  const updateDisplay = useCallback((force = false) => {
    const now = Date.now();
    if (!force && now - lastDisplayUpdateRef.current < 50) return;
    lastDisplayUpdateRef.current = now;
    const g = gameRef.current;
    setCrashDisplay(prev => {
      // When crashed, show exact crash point — no smoothing
      const isCrashed = g.gameState === 'crashed';
      const isBetting = g.gameState === 'betting';

      let displayMult;
      if (isCrashed) {
        displayMult = g.crashPoint || g.multiplier;
      } else if (isBetting) {
        displayMult = 1.0;
      } else {
        // Flying: smooth animation
        const target = g.multiplier;
        const diff = target - prev.displayMultiplier;
        displayMult = Math.abs(diff) < 0.02 ? target : prev.displayMultiplier + diff * 0.4;
      }

      return {
        gameState: g.gameState, multiplier: g.multiplier,
        displayMultiplier: displayMult,
        crashPoint: g.crashPoint, timeLeft: g.timeLeft,
        roundNumber: g.roundNumber, chartPoints: [...g.chartPoints],
        history: [...g.history], screenShake: g.screenShake,
        particles: [...g.particles], roundBets: [...g.roundBets],
        serverSeedHash: g.serverSeedHash, rocketRotation: g.rocketRotation,
      };
    });
  }, []);

  useEffect(() => {
    const generateCrashPoint = () => {
      const float = Math.random();
      if (float < 0.01) return 1.00;
      return Math.max(1.01, parseFloat((0.99 / (1 - float)).toFixed(2)));
    };

    const calculateNextBet = (lastResult) => {
      const settings = autoBetSettingsRef.current;
      const stats = autoBetStatsRef.current;
      let nextBet = stats.currentBet;
      if (lastResult === 'win') {
        if (settings.onWin.action === 'reset') nextBet = settings.baseAmount;
        else if (settings.onWin.action === 'increase') nextBet = stats.currentBet * (1 + settings.onWin.value / 100);
        else if (settings.onWin.action === 'decrease') nextBet = stats.currentBet * (1 - settings.onWin.value / 100);
      } else {
        if (settings.onLoss.action === 'reset') nextBet = settings.baseAmount;
        else if (settings.onLoss.action === 'increase') nextBet = stats.currentBet * (1 + settings.onLoss.value / 100);
        else if (settings.onLoss.action === 'decrease') nextBet = stats.currentBet * (1 - settings.onLoss.value / 100);
      }
      return Math.max(0.01, Math.min(settings.maxBet, nextBet));
    };

    const addTx = (tx) => setTransactions(prev => [{ id: Date.now(), ...tx }, ...prev]);

    const placeBet = (amount) => {
      const userData = userRef.current;
      if (userData.tmcBalance < amount) return false;
      setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance - amount }));
      setCrashUserBet(amount);
      userBetRef.current = amount;
      gameRef.current.roundBets.push({ username: userData.username, amount, status: 'active' });
      addTx({ type: 'bet_debit', amount, direction: 'debit', note: 'Crash bet' });
      return true;
    };

    const cashout = (mult) => {
      if (!userBetRef.current || userCashedRef.current) return;
      const bet = userBetRef.current;
      const winAmount = bet * mult;
      setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance + winAmount }));
      setCrashUserCashed(true);
      userCashedRef.current = true;
      addTx({ type: 'bet_credit', amount: winAmount, direction: 'credit', note: `Crash cashed @ ${mult.toFixed(2)}×` });
      setLiveBets(prev => [{ id: Date.now(), username: userRef.current.username, amount: bet, game: 'Crash', result: 'win', multiplier: mult, profit: (winAmount - bet).toFixed(2) }, ...prev].slice(0, 10));
      const nextBet = calculateNextBet('win');
      setAutoBetStats(prev => ({ ...prev, wins: prev.wins + 1, currentBet: nextBet }));
    };

    // FIXED: Crash now forces immediate display update — no hang
    const crash = (point) => {
      const g = gameRef.current;
      g.gameState = 'crashed';
      g.multiplier = point;
      g.crashPoint = point; // ensure crashPoint is set
      g.screenShake = true;
      g.particles = Array.from({ length: 15 }, (_, i) => ({
        id: Date.now() + i, x: 50 + Math.random() * 20 - 10, y: 50 + Math.random() * 20 - 10,
        vx: (Math.random() - 0.5) * 5, vy: (Math.random() - 0.5) * 5,
        opacity: 1, size: Math.random() * 5 + 2,
        color: ['#FF3D71', '#FFB800', '#FF6B6B', '#FF8C42'][Math.floor(Math.random() * 4)],
      }));
      if (userBetRef.current && !userCashedRef.current) {
        addTx({ type: 'bet_debit', amount: userBetRef.current, direction: 'debit', note: `Crash crashed @ ${point.toFixed(2)}×` });
        const nextBet = calculateNextBet('loss');
        setAutoBetStats(prev => ({ ...prev, losses: prev.losses + 1, currentBet: nextBet }));
      }
      g.history = [point, ...g.history].slice(0, 20);

      // FIXED: Force immediate display update — bypass throttle
      updateDisplay(true);

      setTimeout(() => {
        g.screenShake = false;
        g.roundNumber++;
        startRound();
      }, 3000);
    };

    const startFlying = () => {
      const g = gameRef.current;
      g.gameState = 'flying';
      g.crashPoint = generateCrashPoint();
      g.elapsed = 0;
      g.chartPoints = [{ t: 0, m: 1.0 }];
      let lastParticleTime = 0;

      const flyInterval = setInterval(() => {
        g.elapsed += 0.06;
        g.multiplier = Math.max(1.0, 1.0 + 0.06 * g.elapsed * g.elapsed);

        if (g.multiplier >= g.crashPoint) {
          g.multiplier = g.crashPoint;
          clearInterval(flyInterval);
          crash(g.crashPoint);
          return;
        }

        g.chartPoints.push({ t: g.elapsed, m: g.multiplier });
        if (g.chartPoints.length > 300) {
          g.chartPoints = [g.chartPoints[0], ...g.chartPoints.slice(1, -1).filter((_, i) => i % 2 === 0), g.chartPoints[g.chartPoints.length - 1]];
        }

        if (g.chartPoints.length >= 3) {
          const last = g.chartPoints[g.chartPoints.length - 1];
          const prev = g.chartPoints[Math.max(0, g.chartPoints.length - 4)];
          const dx = last.t - prev.t;
          const dy = last.m - prev.m;
          if (dx > 0) {
            const angle = Math.atan2(dy, dx) * (180 / Math.PI);
            g.rocketRotation = angle - 90;
          }
        }

        const now = Date.now();
        if (now - lastParticleTime > 80) {
          lastParticleTime = now;
          const tx = (g.elapsed / Math.max(8, g.elapsed)) * 100;
          const ty = 100 - ((g.multiplier - 1) / Math.max(10, g.multiplier * 1.2 - 1)) * 100;
          g.particles.push({ id: now, x: tx, y: ty, opacity: 1, size: Math.random() * 3 + 1 });
          if (g.particles.length > 25) g.particles.shift();
        }

        const auto = parseFloat(autoCashoutRef.current);
        if (userBetRef.current && !userCashedRef.current && auto && g.multiplier >= auto) {
          cashout(g.multiplier);
        }

        updateDisplay();
      }, 50);

      timerRef.current = flyInterval;
    };

    const startRound = () => {
      const g = gameRef.current;
      g.gameState = 'betting';
      g.multiplier = 1.0;
      g.crashPoint = null;
      g.elapsed = 0;
      g.chartPoints = [{ t: 0, m: 1.0 }];
      g.particles = [];
      g.screenShake = false;
      g.rocketRotation = -45;
      g.roundBets = [];
      g.serverSeedHash = Math.random().toString(36).substring(2, 18) + '...';
      g.timeLeft = 5;
      setCrashUserBet(null);
      setCrashUserCashed(false);
      userBetRef.current = null;
      userCashedRef.current = false;

      // FIXED: Hard reset display to 1.0x immediately — no smoothing from previous crash
      setCrashDisplay({
        gameState: 'betting', multiplier: 1.0, displayMultiplier: 1.0,
        crashPoint: null, timeLeft: 5, roundNumber: g.roundNumber,
        chartPoints: [{ t: 0, m: 1.0 }], history: [...g.history],
        screenShake: false, particles: [], roundBets: [],
        serverSeedHash: g.serverSeedHash, rocketRotation: -45,
      });

      let countdown = 5;
      const countdownInterval = setInterval(() => {
        countdown -= 1;
        g.timeLeft = countdown;

        if (countdown === 4 && autoBetRef.current && !userBetRef.current) {
          const stats = autoBetStatsRef.current;
          const settings = autoBetSettingsRef.current;
          if ((settings.rounds === 0 || stats.roundsLeft < settings.rounds) &&
              (settings.stopOnWin === 0 || stats.wins < settings.stopOnWin) &&
              (settings.stopOnLoss === 0 || stats.losses < settings.stopOnLoss)) {
            const amt = Math.max(0.01, parseFloat(stats.currentBet) || 0.01);
            if (placeBet(amt)) {
              setAutoBetStats(prev => ({ ...prev, roundsLeft: prev.roundsLeft + 1 }));
            } else {
              setCrashAutoBet(false);
            }
          } else {
            setCrashAutoBet(false);
          }
        }

        updateDisplay();
        if (countdown <= 0) {
          clearInterval(countdownInterval);
          startFlying();
        }
      }, 1000);

      timerRef.current = countdownInterval;
    };

    startRound();
    return () => clearInterval(timerRef.current);
  }, []);

  const getValidBetAmount = () => {
    const val = parseFloat(crashBetAmount);
    if (isNaN(val) || val < 0.01) return null;
    return val;
  };

  const handleManualBet = useCallback(() => {
    const amt = getValidBetAmount();
    if (!amt) { alert('Minimum bet is 0.01 TMC'); return; }
    if (user.tmcBalance < amt) { alert('Insufficient balance!'); return; }
    if (gameRef.current.gameState !== 'betting') { alert('Betting closed!'); return; }
    setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance - amt }));
    setCrashUserBet(amt);
    userBetRef.current = amt;
    gameRef.current.roundBets.push({ username: user.username, amount: amt, status: 'active' });
    setTransactions(prev => [{ id: Date.now(), type: 'bet_debit', amount: amt, direction: 'debit', note: 'Crash bet' }, ...prev]);
  }, [crashBetAmount, user.tmcBalance, user.username]);

  const handleManualCashout = useCallback(() => {
    if (!userBetRef.current || userCashedRef.current || gameRef.current.gameState !== 'flying') return;
    const mult = gameRef.current.multiplier;
    const bet = userBetRef.current;
    const winAmount = bet * mult;
    setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance + winAmount }));
    setCrashUserCashed(true);
    userCashedRef.current = true;
    setTransactions(prev => [{ id: Date.now(), type: 'bet_credit', amount: winAmount, direction: 'credit', note: `Crash cashed @ ${mult.toFixed(2)}×` }, ...prev]);
    setLiveBets(prev => [{ id: Date.now(), username: user.username, amount: bet, game: 'Crash', result: 'win', multiplier: mult, profit: (winAmount - bet).toFixed(2) }, ...prev].slice(0, 10));
  }, [user.username]);

  const toggleAutoBet = useCallback(() => {
    setCrashAutoBet(prev => {
      const next = !prev;
      if (next) setAutoBetStats({ wins: 0, losses: 0, currentBet: autoBetSettings.baseAmount, roundsLeft: 0 });
      return next;
    });
  }, [autoBetSettings.baseAmount]);

  useEffect(() => { localStorage.setItem('tonmine_user', JSON.stringify(user)); }, [user]);
  useEffect(() => {
    const interval = setInterval(() => {
      setUser(prev => { const now = Date.now(); const elapsed = (now - prev.lastActiveAt) / 1000; const earned = (prev.miningRate * elapsed) / 3600; return { ...prev, tmcBalance: prev.tmcBalance + earned, totalMined: prev.totalMined + earned, totalMinedEver: prev.totalMinedEver + earned, lastActiveAt: now }; });
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  useEffect(() => {
    const interval = setInterval(() => {
      setUser(prev => { const now = Date.now(); const regen = Math.floor((now - prev.lastEnergyRegen) / 3000); if (regen > 0) return { ...prev, energy: Math.min(prev.maxEnergy, prev.energy + regen), lastEnergyRegen: now }; return prev; });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const addFloatingText = (text, x, y) => { const id = Date.now(); setFloatingTexts(prev => [...prev, { id, text, x, y }]); setTimeout(() => setFloatingTexts(prev => prev.filter(t => t.id !== id)), 1000); };
  const addTx = (tx) => setTransactions(prev => [{ id: Date.now(), ...tx }, ...prev]);

  return (
    <div className="relative min-h-screen w-full bg-[#050508] flex flex-col overflow-auto">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-20 -left-20 w-72 h-72 bg-gold rounded-full opacity-[0.07] blur-[100px] animate-drift" />
        <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-cyan rounded-full opacity-[0.05] blur-[100px] animate-drift-reverse" />
        <div className="absolute top-1/2 right-0 w-64 h-64 bg-purple rounded-full opacity-[0.04] blur-[80px] animate-drift" />
        <div className="absolute inset-0 bg-dot-grid opacity-50" />
      </div>

      <Header user={user} />
      <LiveTicker />

      <main className="flex-1 overflow-y-auto overflow-x-hidden pb-24 px-4 pt-2 relative z-10 w-full max-w-[430px] mx-auto">
        {activeTab === 'mine' && <MineTab user={user} setUser={setUser} addFloatingText={addFloatingText} addTransaction={addTx} />}
        {activeTab === 'casino' && <CasinoTab user={user} setUser={setUser} liveBets={liveBets} setLiveBets={setLiveBets} addTransaction={addTx} crashDisplay={crashDisplay} crashUserBet={crashUserBet} crashUserCashed={crashUserCashed} crashBetAmount={crashBetAmount} setCrashBetAmount={setCrashBetAmount} crashAutoCashout={crashAutoCashout} setCrashAutoCashout={setCrashAutoCashout} crashAutoBet={crashAutoBet} toggleAutoBet={toggleAutoBet} autoBetSettings={autoBetSettings} setAutoBetSettings={setAutoBetSettings} autoBetStats={autoBetStats} showAutoBetSettings={showAutoBetSettings} setShowAutoBetSettings={setShowAutoBetSettings} onManualBet={handleManualBet} onManualCashout={handleManualCashout} getValidBetAmount={getValidBetAmount} />}
        {activeTab === 'ranks' && <RanksTab user={user} />}
        {activeTab === 'wallet' && <WalletTab user={user} setUser={setUser} transactions={transactions} addTransaction={addTx} />}
      </main>

      {floatingTexts.map(ft => <div key={ft.id} className="fixed z-50 font-orbitron text-gold font-bold text-sm pointer-events-none animate-float-up" style={{ left: ft.x, top: ft.y }}>{ft.text}</div>)}

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}


function Header({ user }) {
  return (
    <header className="sticky top-0 z-40 bg-[rgba(5,5,8,0.85)] backdrop-blur-md border-b border-border w-full">
      <div className="flex items-center justify-between px-4 h-14 max-w-[430px] mx-auto">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-gold" />
          <span className="font-orbitron font-bold text-lg tracking-wider shimmer-text">TONMINE</span>
        </div>
        <div className="flex items-center gap-2 glass-card px-3 py-1.5">
          <span className="font-orbitron text-gold font-bold text-sm">{formatTMC(user.tmcBalance)}</span>
          <span className="text-[10px] text-text-secondary font-medium">TMC</span>
        </div>
      </div>
    </header>
  );
}

function LiveTicker() {
  const [online, setOnline] = useState(1247);
  useEffect(() => { const interval = setInterval(() => setOnline(o => o + Math.floor(Math.random() * 5) - 2), 5000); return () => clearInterval(interval); }, []);
  return (
    <div className="sticky top-14 z-30 bg-[rgba(5,5,8,0.9)] border-b border-border py-1.5 px-4 overflow-x-auto w-full">
      <div className="flex items-center gap-2 text-xs whitespace-nowrap max-w-[430px] mx-auto">
        <span className="text-green font-bold animate-pulse-live">● LIVE</span>
        <span className="text-text-secondary">|</span>
        <span className="text-text-secondary">Total Mined: <span className="text-gold font-orbitron">4.89M TMC</span></span>
        <span className="text-text-secondary">|</span>
        <span className="text-text-secondary">Online: <span className="text-cyan font-orbitron">{online}</span></span>
        <span className="text-text-secondary">|</span>
        <span className="text-text-secondary">1 TON = 1,000 TMC</span>
      </div>
    </div>
  );
}

function BottomNav({ activeTab, setActiveTab }) {
  const tabs = [
    { id: 'mine', icon: Pickaxe, label: 'Mine' },
    { id: 'casino', icon: Gamepad2, label: 'Casino' },
    { id: 'ranks', icon: Trophy, label: 'Ranks' },
    { id: 'wallet', icon: Wallet, label: 'Wallet' },
  ];
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[rgba(5,5,8,0.95)] backdrop-blur-lg border-t border-border w-full">
      <div className="max-w-[430px] mx-auto flex items-center justify-around h-16">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`relative flex flex-col items-center gap-1 w-16 transition-all duration-200 ${isActive ? 'text-gold' : 'text-text-secondary opacity-50'}`}>
              <Icon className={`w-5 h-5 ${isActive ? 'drop-shadow-[0_0_8px_rgba(255,184,0,0.5)]' : ''}`} />
              <span className="text-[10px] font-medium font-sora">{tab.label}</span>
              {isActive && <div className="absolute bottom-0 w-8 h-0.5 bg-gold rounded-full shadow-[0_0_10px_rgba(255,184,0,0.5)]" />}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function MineTab({ user, setUser, addFloatingText, addTransaction }) {
  const [orbActive, setOrbActive] = useState(false);
  const [countdown, setCountdown] = useState('');
  const orbRef = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      const lastTap = user.lastDailyTapAt || 0;
      const msRemaining = 86400000 - (now - lastTap);
      if (msRemaining <= 0) setCountdown('');
      else { const h = Math.floor(msRemaining / 3600000), m = Math.floor((msRemaining % 3600000) / 60000), s = Math.floor((msRemaining % 60000) / 1000); setCountdown(`${h}h ${m}m ${s}s`); }
    }, 1000);
    return () => clearInterval(interval);
  }, [user.lastDailyTapAt]);

  const canTap = () => { const now = Date.now(); return (now - (user.lastDailyTapAt || 0)) >= 86400000; };

  const handleTap = (e) => {
    if (!canTap()) return;
    const dailyReward = user.miningRate * 24;
    const rect = orbRef.current?.getBoundingClientRect();
    const x = rect ? rect.left + rect.width / 2 : e.clientX;
    const y = rect ? rect.top : e.clientY;
    setUser(prev => ({ ...prev, lastDailyTapAt: Date.now(), tmcBalance: prev.tmcBalance + dailyReward, totalMined: prev.totalMined + dailyReward, totalMinedEver: prev.totalMinedEver + dailyReward, lastTapAt: Date.now() }));
    addFloatingText(`+${dailyReward.toFixed(2)} TMC`, x, y);
    setOrbActive(true); setTimeout(() => setOrbActive(false), 100);
  };

  const getLeague = (mined) => {
    if (mined >= 1000000) return { name: 'Legend', icon: '👑', color: '#C084FC' };
    if (mined >= 100000) return { name: 'Diamond', icon: '💎', color: '#00E5FF' };
    if (mined >= 10000) return { name: 'Gold', icon: '🥇', color: '#FFB800' };
    if (mined >= 1000) return { name: 'Silver', icon: '🥈', color: '#94A3B8' };
    return { name: 'Bronze', icon: '🥉', color: '#CD7F32' };
  };
  const league = getLeague(user.totalMinedEver);

  const upgrades = [
    { level: 1, name: 'Basic Miner', rate: 0.5, cost: 0, icon: '⛏️' },
    { level: 2, name: 'Fast Miner', rate: 1.0, cost: 500, icon: '⚡' },
    { level: 3, name: 'Turbo Miner', rate: 2.5, cost: 2000, icon: '🚀' },
    { level: 4, name: 'Quantum Miner', rate: 5.0, cost: 8000, icon: '⚛️' },
    { level: 5, name: 'Galactic Miner', rate: 12.0, cost: 25000, icon: '🌌' },
  ];

  const handleUpgrade = (upg) => {
    if (user.miningLevel >= upg.level) return;
    if (user.tmcBalance < upg.cost) { alert('Insufficient TMC!'); return; }
    setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance - upg.cost, miningRate: upg.rate, miningLevel: upg.level }));
    addTransaction({ type: 'upgrade_purchase', amount: upg.cost, direction: 'debit', note: `Upgraded to ${upg.name}` });
  };

  const handleDailyClaim = () => {
    const now = Date.now(), lastClaim = user.lastClaimAt || 0, hoursSince = (now - lastClaim) / 3600000;
    if (hoursSince < 20) { alert('Not ready yet!'); return; }
    const streak = hoursSince > 48 ? 1 : user.claimStreak + 1;
    const mult = streak >= 30 ? 10 : streak >= 7 ? 3 : 1;
    const amount = user.miningRate * 24 * mult;
    setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance + amount, totalMined: prev.totalMined + amount, totalMinedEver: prev.totalMinedEver + amount, claimStreak: streak, lastClaimAt: now }));
    addTransaction({ type: 'mining_daily', amount, direction: 'credit', note: `Day ${streak} streak` });
  };

  const tapAvailable = canTap();
  const canClaim = ((Date.now() - (user.lastClaimAt || 0)) / 3600000) >= 20;

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="grid grid-cols-2 gap-3">
        <div className="glass-card p-3">
          <div className="text-[10px] text-text-secondary uppercase tracking-wider mb-1">Mining Rate</div>
          <div className="font-orbitron text-lg text-gold">{user.miningRate} <span className="text-xs text-text-secondary">TMC/hr</span></div>
        </div>
        <div className="glass-card p-3">
          <div className="text-[10px] text-text-secondary uppercase tracking-wider mb-1">Total Mined</div>
          <div className="font-orbitron text-lg text-cyan">{formatTMC(user.totalMined)}</div>
        </div>
      </div>

      <div className="glass-card p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{league.icon}</span>
          <div>
            <div className="text-xs text-text-secondary">Current League</div>
            <div className="font-orbitron font-bold" style={{ color: league.color }}>{league.name}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] text-text-secondary">Next Rank</div>
          <div className="font-orbitron text-xs text-text-secondary">{league.name === 'Legend' ? 'MAX' : formatTMC(league.name === 'Bronze' ? 1000 : league.name === 'Silver' ? 10000 : league.name === 'Gold' ? 100000 : 1000000)} TMC</div>
        </div>
      </div>

      <div className="flex flex-col items-center py-6">
        <div ref={orbRef} onClick={handleTap} className={`relative w-36 h-36 cursor-pointer transition-transform duration-100 select-none ${orbActive ? 'scale-[0.91]' : 'scale-100'} ${!tapAvailable ? 'opacity-60' : ''}`}>
          <div className={`absolute inset-0 rounded-full border-2 border-dashed border-gold/30 ${tapAvailable ? 'animate-spin-slow' : ''}`} />
          <div className={`absolute inset-2 rounded-full border border-cyan/20 ${tapAvailable ? 'animate-spin-reverse' : ''}`} />
          {tapAvailable && (<><div className="orb-pulse absolute inset-0" /><div className="orb-pulse absolute inset-0" style={{ animationDelay: '1s' }} /></>)}
          <div className={`absolute inset-4 rounded-full border transition-all duration-500 ${tapAvailable ? 'border-gold/20 shadow-[0_0_30px_rgba(255,184,0,0.15)]' : 'border-white/5 shadow-none'}`} />
          <div className={`absolute inset-6 rounded-full flex items-center justify-center transition-all duration-500 ${tapAvailable ? 'bg-gradient-radial from-yellow-300 via-amber-500 to-amber-700 shadow-[0_0_40px_rgba(255,184,0,0.3)]' : 'bg-gray-800 shadow-none'}`}>
            <div className={`absolute top-3 left-4 w-8 h-5 rounded-full blur-sm transition-opacity ${tapAvailable ? 'bg-white/20' : 'bg-white/5'}`} />
            <div className="text-center">
              <div className={`font-orbitron font-bold text-lg leading-none transition-colors ${tapAvailable ? 'text-[#050508]' : 'text-text-muted'}`}>{tapAvailable ? 'TAP' : 'WAIT'}</div>
              <div className={`text-[10px] font-bold mt-0.5 transition-colors ${tapAvailable ? 'text-[#050508]/70' : 'text-text-muted'}`}>{tapAvailable ? '24H MINING' : 'NEXT TAP'}</div>
            </div>
          </div>
        </div>

        <div className="w-48 mt-4 text-center">
          {tapAvailable ? (
            <div className="text-xs text-gold font-medium animate-pulse">⚡ Daily mining ready! Tap to activate</div>
          ) : (
            <div className="space-y-1">
              <div className="text-[10px] text-text-secondary mb-1 font-orbitron">NEXT TAP IN</div>
              <div className="h-2 bg-surface rounded-full overflow-hidden border border-border">
                <div className="h-full bg-gold/50 transition-all duration-1000" style={{ width: `${Math.max(0, Math.min(100, ((Date.now() - (user.lastDailyTapAt || 0)) / 86400000) * 100))}%` }} />
              </div>
              <div className="font-orbitron text-sm text-gold">{countdown}</div>
              <div className="text-[10px] text-text-muted">Mining passively at {user.miningRate} TMC/hr</div>
            </div>
          )}
        </div>
      </div>

      <div className="glass-card-gold p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-gold" /><span className="font-orbitron text-sm text-gold">Daily Bonus</span></div>
          <span className="text-xs text-text-secondary">Streak: {user.claimStreak} days</span>
        </div>
        <div className="flex items-center justify-between">
          <div className="text-xs text-text-secondary">{canClaim ? 'Ready!' : 'Come back in 24h'}</div>
          <button onClick={handleDailyClaim} disabled={!canClaim} className="btn-gold px-4 py-2 text-xs disabled:opacity-30">CLAIM</button>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-orbitron text-sm text-text-secondary uppercase tracking-wider px-1">Mining Upgrades</h3>
        {upgrades.map(upg => {
          const isActive = user.miningLevel === upg.level;
          const isLocked = user.miningLevel < upg.level - 1;
          const canBuy = user.tmcBalance >= upg.cost && !isActive && !isLocked;
          return (
            <div key={upg.level} className={`glass-card p-3 flex items-center justify-between ${isActive ? 'glass-card-gold' : ''}`}>
              <div className="flex items-center gap-3"><span className="text-xl">{upg.icon}</span><div><div className="font-sora font-semibold text-sm">{upg.name}</div><div className="text-[10px] text-text-secondary">{upg.rate} TMC/hr</div></div></div>
              <div className="flex items-center gap-2">
                {isActive ? <span className="text-xs text-cyan font-bold px-2 py-1 bg-cyan/10 rounded">ACTIVE ✓</span> :
                 isLocked ? <span className="text-xs text-text-muted px-2 py-1 bg-surface rounded">LOCKED</span> :
                 <button onClick={() => handleUpgrade(upg)} className={`px-3 py-1.5 rounded text-xs font-bold font-orbitron ${canBuy ? 'btn-gold' : 'bg-surface text-text-muted'}`}>{upg.cost === 0 ? 'FREE' : `${formatTMC(upg.cost)} TMC`}</button>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CasinoTab({ user, setUser, liveBets, setLiveBets, addTransaction, crashDisplay, crashUserBet, crashUserCashed, crashBetAmount, setCrashBetAmount, crashAutoCashout, setCrashAutoCashout, crashAutoBet, toggleAutoBet, autoBetSettings, setAutoBetSettings, autoBetStats, showAutoBetSettings, setShowAutoBetSettings, onManualBet, onManualCashout, getValidBetAmount }) {
  const [subTab, setSubTab] = useState('crash');
  return (
    <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="glass-card p-2 overflow-hidden">
        <div className="flex items-center gap-2 mb-2 px-1">
          <div className="w-1.5 h-1.5 rounded-full bg-green animate-pulse-live" />
          <span className="text-[10px] text-text-secondary uppercase tracking-wider">Live Bets</span>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-1 text-xs whitespace-nowrap">
          {liveBets.map(bet => (
            <div key={bet.id} className="flex items-center gap-1.5">
              <span className={bet.result === 'win' ? 'text-green' : 'text-red'}>{bet.result === 'win' ? '✅' : '💥'}</span>
              <span className="text-text-secondary">{bet.username}</span>
              <span className={bet.result === 'win' ? 'text-green' : 'text-red'}>{bet.result === 'win' ? `+${bet.profit}` : bet.profit} TMC</span>
              <span className="text-text-muted">on {bet.game}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="flex gap-2 p-1 bg-surface rounded-xl">
        {[{ id: 'crash', icon: '🚀', label: 'Crash' }, { id: 'dice', icon: '🎲', label: 'Dice' }, { id: 'limbo', icon: '🎯', label: 'Limbo' }].map(tab => (
          <button key={tab.id} onClick={() => setSubTab(tab.id)} className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition-all ${subTab === tab.id ? 'bg-gold/20 text-gold border border-gold/30' : 'text-text-secondary hover:text-text-primary'}`}>
            <span>{tab.icon}</span><span className="font-sora">{tab.label}</span>
          </button>
        ))}
      </div>
      <div className="min-h-[400px]">
        {subTab === 'crash' && <CrashGame user={user} crashDisplay={crashDisplay} crashUserBet={crashUserBet} crashUserCashed={crashUserCashed} crashBetAmount={crashBetAmount} setCrashBetAmount={setCrashBetAmount} crashAutoCashout={crashAutoCashout} setCrashAutoCashout={setCrashAutoCashout} crashAutoBet={crashAutoBet} toggleAutoBet={toggleAutoBet} autoBetSettings={autoBetSettings} setAutoBetSettings={setAutoBetSettings} autoBetStats={autoBetStats} showAutoBetSettings={showAutoBetSettings} setShowAutoBetSettings={setShowAutoBetSettings} onManualBet={onManualBet} onManualCashout={onManualCashout} getValidBetAmount={getValidBetAmount} />}
        {subTab === 'dice' && <DiceGame user={user} setUser={setUser} addTransaction={addTransaction} />}
        {subTab === 'limbo' && <LimboGame user={user} setUser={setUser} addTransaction={addTransaction} />}
      </div>
    </div>
  );
}


function CrashGame({ user, crashDisplay, crashUserBet, crashUserCashed, crashBetAmount, setCrashBetAmount, crashAutoCashout, setCrashAutoCashout, crashAutoBet, toggleAutoBet, autoBetSettings, setAutoBetSettings, autoBetStats, showAutoBetSettings, setShowAutoBetSettings, onManualBet, onManualCashout, getValidBetAmount }) {
  const { gameState, displayMultiplier, crashPoint, timeLeft, roundNumber, chartPoints, history, screenShake, particles, rocketRotation, roundBets, serverSeedHash } = crashDisplay;
  const [controlTab, setControlTab] = useState('manual');

  const isBetting = gameState === 'betting';
  const isFlying = gameState === 'flying';
  const isCrashed = gameState === 'crashed';
  const hasBet = crashUserBet !== null;
  const hasCashed = crashUserCashed;
  const validBet = getValidBetAmount();

  const handleBetInput = (e) => {
    const val = e.target.value;
    if (val === '' || val === '.') { setCrashBetAmount(val); return; }
    const num = parseFloat(val);
    if (isNaN(num) || num < 0) return;
    setCrashBetAmount(val);
  };

  const handleAutoCashoutInput = (e) => {
    const val = e.target.value;
    if (val === '' || val === '.') { setCrashAutoCashout(val); return; }
    const num = parseFloat(val);
    if (isNaN(num) || num < 1.01) return;
    setCrashAutoCashout(val);
  };

  const updateAutoBetSetting = (key, subKey, value) => {
    setAutoBetSettings(prev => ({ ...prev, [key]: { ...prev[key], [subKey]: value } }));
  };

  const halfBet = () => {
    const current = parseFloat(crashBetAmount) || 0.01;
    const next = Math.max(0.01, current / 2);
    setCrashBetAmount(next.toString());
  };
  const doubleBet = () => {
    const current = parseFloat(crashBetAmount) || 0.01;
    setCrashBetAmount((current * 2).toString());
  };
  const setPreset = (n) => setCrashBetAmount(n.toString());

  // SVG
  const maxT = Math.max(8, chartPoints[chartPoints.length - 1]?.t || 8);
  const maxM = Math.max(10, crashDisplay.multiplier * 1.2);

  const generateSmoothPath = (pts) => {
    if (pts.length < 2) return '';
    let path = `M ${(pts[0].t / maxT) * 100} ${100 - ((pts[0].m - 1) / (maxM - 1)) * 100}`;
    for (let i = 1; i < pts.length; i++) {
      const prev = pts[i - 1], curr = pts[i];
      const x1 = (prev.t / maxT) * 100, y1 = 100 - ((prev.m - 1) / (maxM - 1)) * 100;
      const x2 = (curr.t / maxT) * 100, y2 = 100 - ((curr.m - 1) / (maxM - 1)) * 100;
      const cpx = (x1 + x2) / 2, cpy = (y1 + y2) / 2;
      path += ` Q ${cpx} ${cpy}, ${x2} ${y2}`;
    }
    return path;
  };

  const smoothPath = generateSmoothPath(chartPoints);
  const areaPath = smoothPath + ` L ${(chartPoints[chartPoints.length - 1]?.t / maxT) * 100 || 0} 100 L 0 100 Z`;
  const currentX = chartPoints.length > 0 ? (chartPoints[chartPoints.length - 1].t / maxT) * 100 : 0;
  const currentY = chartPoints.length > 0 ? 100 - ((chartPoints[chartPoints.length - 1].m - 1) / (maxM - 1)) * 100 : 100;

  const getLineColor = (m) => { if (m < 2) return '#00E096'; if (m < 5) return '#FFB800'; if (m < 10) return '#00E5FF'; return '#C084FC'; };
  const currentColor = isCrashed ? '#FF3D71' : getLineColor(crashDisplay.multiplier);

  return (
    <div className={`space-y-3 ${screenShake ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}>
      {/* History */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {history.map((h, i) => (
          <button key={i} className={`flex-shrink-0 px-2 py-1 rounded-lg text-xs font-orbitron font-bold transition-all hover:scale-105 ${h >= 2 ? 'bg-green/20 text-green border border-green/30' : h >= 1.5 ? 'bg-gold/20 text-gold border border-gold/30' : 'bg-red/20 text-red border border-red/30'}`}>
            {h.toFixed(2)}×
          </button>
        ))}
      </div>

      {/* Chart — NO screenshot button, clean */}
      <div className={`glass-card p-0 relative h-64 overflow-hidden ${isCrashed ? 'lose-flash' : ''}`}>
        <svg width="0" height="0" className="absolute">
          <defs>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3" result="coloredBlur"/><feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            <filter id="strongGlow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6" result="coloredBlur"/><feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
            <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={currentColor} stopOpacity="0.3" /><stop offset="100%" stopColor={currentColor} stopOpacity="0" /></linearGradient>
          </defs>
        </svg>

        <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="none">
          {[1, 2, 3, 5, 10, 20, 50].map(g => {
            const y = 100 - ((g - 1) / (maxM - 1)) * 100;
            if (y < 0 || y > 100 || g > maxM) return null;
            return (
              <g key={g}>
                <line x1="0" y1={y} x2="100" y2={y} stroke="rgba(255,255,255,0.04)" strokeWidth="0.2" />
                <text x="2" y={y - 1} fontSize="2.5" fill="rgba(255,255,255,0.2)" fontFamily="Orbitron">{g}×</text>
              </g>
            );
          })}
          {[2, 4, 6, 8].map(t => {
            const x = (t / maxT) * 100;
            if (x > 100) return null;
            return <line key={t} x1={x} y1="0" x2={x} y2="100" stroke="rgba(255,255,255,0.02)" strokeWidth="0.2" strokeDasharray="1,2" />;
          })}

          {smoothPath && !isBetting && <path d={areaPath} fill="url(#areaGradient)" opacity="0.6" />}
          {smoothPath && !isBetting && <path d={smoothPath} fill="none" stroke={currentColor} strokeWidth="0.8" strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 2px ${currentColor}) drop-shadow(0 0 4px ${currentColor})` }} />}
          {smoothPath && !isBetting && <path d={smoothPath} fill="none" stroke={currentColor} strokeWidth="0.3" strokeLinecap="round" opacity="0.9" />}

          {isFlying && particles.map(p => <circle key={p.id} cx={p.x} cy={p.y} r={p.size * 0.15} fill={currentColor} opacity={p.opacity * 0.4} />)}

          {isFlying && (
            <g transform={`translate(${currentX}, ${currentY}) rotate(${rocketRotation})`}>
              <circle cx="0" cy="0" r="4" fill={currentColor} opacity="0.2" filter="url(#strongGlow)" />
              <path d="M 0,-6 L 2.5,2 L 0,0 L -2.5,2 Z" fill="#FFB800" stroke="#FF8C00" strokeWidth="0.3" />
              <path d="M 0,-6 L 1,0 L 0,1 L -1,0 Z" fill="#FFE066" />
              <path d="M 0,0 L 3,3 L 1,1 Z" fill="#FF8C00" opacity="0.9" />
              <path d="M 0,0 L -3,3 L -1,1 Z" fill="#FF8C00" opacity="0.9" />
              <ellipse cx="0" cy="3" rx="1.5" ry="3" fill="#FF6B00" opacity="0.8" />
              <ellipse cx="0" cy="4" rx="1" ry="2" fill="#FFB800" opacity="0.6" />
            </g>
          )}

          {isCrashed && particles.map((p, i) => <circle key={p.id} cx={p.x + (Date.now() - p.id) * p.vx * 0.01} cy={p.y + (Date.now() - p.id) * p.vy * 0.01} r={p.size * 0.2} fill={p.color} opacity={Math.max(0, 1 - (Date.now() - p.id) / 1000)} />)}

          {isCrashed && (
            <g transform={`translate(${currentX}, ${currentY})`}>
              <text x="0" y="0" fontSize="6" textAnchor="middle" dominantBaseline="middle" fill="#FF3D71" style={{ filter: 'drop-shadow(0 0 5px #FF3D71)' }}>💥</text>
              <line x1="-3" y1="-3" x2="3" y2="3" stroke="#FF3D71" strokeWidth="0.5" opacity="0.6" />
              <line x1="3" y1="-3" x2="-3" y2="3" stroke="#FF3D71" strokeWidth="0.5" opacity="0.6" />
            </g>
          )}

          {isBetting && (
            <g>
              <line x1="0" y1="95" x2="100" y2="95" stroke="#00E096" strokeWidth="0.3" strokeDasharray="2,2" opacity="0.5" />
              <text x="50" y="90" fontSize="4" textAnchor="middle" fill="#00E096" fontFamily="Orbitron" opacity="0.8">PREPARING FOR LAUNCH...</text>
            </g>
          )}
        </svg>

        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
          <div className={`font-orbitron text-5xl font-bold transition-colors duration-300 ${isCrashed ? 'text-red' : displayMultiplier < 2 ? 'text-green' : displayMultiplier < 5 ? 'text-gold' : displayMultiplier < 10 ? 'text-cyan' : 'text-purple'}`} style={{ textShadow: `0 0 20px ${currentColor}40` }}>
            {displayMultiplier.toFixed(2)}×
          </div>
          {isBetting && <div className="text-xs text-green mt-1 font-bold animate-pulse">LAUNCH IN {timeLeft}s</div>}
          {isCrashed && <div className="text-xs text-red mt-1 font-bold">CRASHED @ {crashPoint?.toFixed(2)}×</div>}
        </div>
      </div>

      {/* Controls */}
      <div className="space-y-2">
        {/* Tabs */}
        <div className="flex justify-center">
          <div className="flex gap-1 p-0.5 bg-surface rounded-lg w-full">
            {['manual', 'auto', 'advanced'].map(tab => (
              <button
                key={tab}
                onClick={() => setControlTab(tab)}
                className={`flex-1 py-2 rounded-md text-xs font-bold font-sora transition-all text-center ${
                  controlTab === tab 
                    ? 'bg-gold/20 text-gold border border-gold/30' 
                    : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                {tab === 'manual' && 'Manual'}
                {tab === 'auto' && (
                  <span className="flex items-center justify-center gap-1">
                    Auto {crashAutoBet && <span className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />}
                  </span>
                )}
                {tab === 'advanced' && (
                  <span className="flex items-center justify-center gap-1">
                    Advanced <span className="text-[8px] bg-gold/20 text-gold px-1 rounded">New</span>
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Inputs */}
        <div className="flex gap-2">
          <div className="flex-1 glass-card p-2">
            <div className="text-[9px] text-text-secondary uppercase tracking-wider mb-1">Amount</div>
            <div className="flex items-center gap-1">
              <span className="text-gold text-xs">◎</span>
              <input type="number" value={crashBetAmount} onChange={handleBetInput} className="flex-1 bg-transparent font-orbitron text-sm outline-none min-w-0" min="0.01" max="10000" step="0.01" />
              <div className="flex gap-0.5 flex-shrink-0">
                <button onClick={halfBet} className="px-1.5 py-0.5 bg-surface rounded text-[9px] font-bold text-text-secondary hover:text-gold">1/2</button>
                <button onClick={doubleBet} className="px-1.5 py-0.5 bg-surface rounded text-[9px] font-bold text-text-secondary hover:text-gold">2×</button>
              </div>
            </div>
          </div>
          <div className="flex-1 glass-card p-2">
            <div className="text-[9px] text-text-secondary uppercase tracking-wider mb-1">Auto Cashout</div>
            <div className="flex items-center gap-1">
              <input type="number" value={crashAutoCashout} onChange={handleAutoCashoutInput} placeholder="1.01" className="flex-1 bg-transparent font-orbitron text-sm outline-none min-w-0" min="1.01" step="0.01" />
              <span className="text-xs text-text-secondary font-bold flex-shrink-0">×</span>
            </div>
          </div>
        </div>

        {/* Presets */}
        <div className="grid grid-cols-4 gap-1.5">
          {[1, 10, 100, 1000].map(n => (
            <button key={n} onClick={() => setPreset(n)} className="py-1.5 rounded-lg text-xs font-bold font-orbitron glass-card text-text-secondary hover:text-gold hover:border-gold/30 transition-all">
              {n >= 1000 ? (n/1000).toFixed(1) + 'k' : n}
            </button>
          ))}
        </div>

        {/* MANUAL TAB */}
        {controlTab === 'manual' && (
          <div className="space-y-2">
            {isBetting && !hasBet && (
              <button 
                onClick={onManualBet} 
                disabled={!validBet || user.tmcBalance < validBet}
                className="w-full bg-green hover:bg-green/80 disabled:bg-surface disabled:text-text-muted text-[#050508] py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 disabled:cursor-not-allowed"
              >
                {validBet ? `BET ${validBet.toFixed(2)} TMC` : 'MIN 0.01 TMC'}
              </button>
            )}
            {isFlying && hasBet && !hasCashed && (
              <button onClick={onManualCashout} className="w-full bg-gold hover:bg-gold/80 text-[#050508] py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 animate-pulse">
                CASHOUT @ {displayMultiplier.toFixed(2)}×
              </button>
            )}
            {isFlying && (!hasBet || hasCashed) && (
              <button disabled className="w-full bg-surface text-text-muted py-3.5 rounded-xl text-sm font-bold font-sora border border-border">
                {hasCashed ? '✓ CASHED OUT' : 'BET NEXT ROUND'}
              </button>
            )}
            {isCrashed && (
              <button disabled className="w-full bg-red/10 text-red border border-red/20 py-3.5 rounded-xl text-sm font-bold font-orbitron">
                💥 CRASHED — NEXT ROUND
              </button>
            )}
          </div>
        )}

        {/* AUTO TAB */}
        {controlTab === 'auto' && (
          <div className="space-y-2">
            <div className="glass-card p-2">
              <div className="text-[9px] text-text-secondary mb-1">Number of Bets</div>
              <div className="flex gap-1">
                <button onClick={() => setAutoBetSettings(prev => ({ ...prev, rounds: 0 }))} className={`flex-1 py-1.5 rounded text-xs font-bold ${autoBetSettings.rounds === 0 ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}>
                  <Infinity className="w-3 h-3 mx-auto" />
                </button>
                {[10, 100].map(n => (
                  <button key={n} onClick={() => setAutoBetSettings(prev => ({ ...prev, rounds: n }))} className={`flex-1 py-1.5 rounded text-xs font-bold ${autoBetSettings.rounds === n ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}>
                    {n}
                  </button>
                ))}
                <input type="number" value={autoBetSettings.rounds} onChange={e => setAutoBetSettings(prev => ({ ...prev, rounds: Number(e.target.value) }))} className="w-14 bg-surface rounded text-xs font-orbitron text-center outline-none" min="0" />
              </div>
            </div>

            <button 
              onClick={toggleAutoBet}
              className={`w-full py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 ${
                crashAutoBet 
                  ? 'bg-red/20 text-red border border-red/30 hover:bg-red/30' 
                  : 'bg-green hover:bg-green/80 text-[#050508]'
              }`}
            >
              {crashAutoBet ? `STOP AUTO (${autoBetStats.wins}W/${autoBetStats.losses}L)` : 'START AUTO BET'}
            </button>

            <div className="glass-card p-2">
              <button onClick={() => setShowAutoBetSettings(!showAutoBetSettings)} className="w-full flex items-center justify-between text-xs font-bold text-text-secondary">
                <span>Advanced Options</span>
                {showAutoBetSettings ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>

              {showAutoBetSettings && (
                <div className="space-y-3 mt-2 pt-2 border-t border-border">
                  <div className="space-y-1">
                    <div className="text-[9px] text-text-secondary">On Win</div>
                    <div className="flex gap-1">
                      <button onClick={() => updateAutoBetSetting('onWin', 'action', 'reset')} className={`flex-1 py-1.5 rounded text-[10px] font-bold ${autoBetSettings.onWin.action === 'reset' ? 'bg-green/20 text-green border border-green/30' : 'glass-card text-text-secondary'}`}>Reset</button>
                      <button onClick={() => updateAutoBetSetting('onWin', 'action', 'increase')} className={`flex-1 py-1.5 rounded text-[10px] font-bold ${autoBetSettings.onWin.action === 'increase' ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>Increase by</button>
                    </div>
                    {autoBetSettings.onWin.action !== 'reset' && (
                      <div className="flex items-center gap-1 mt-1">
                        <input type="number" value={autoBetSettings.onWin.value} onChange={e => updateAutoBetSetting('onWin', 'value', Number(e.target.value))} className="flex-1 bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0" max="500" />
                        <span className="text-xs text-text-secondary font-bold">%</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="text-[9px] text-text-secondary">On Loss</div>
                    <div className="flex gap-1">
                      <button onClick={() => updateAutoBetSetting('onLoss', 'action', 'reset')} className={`flex-1 py-1.5 rounded text-[10px] font-bold ${autoBetSettings.onLoss.action === 'reset' ? 'bg-green/20 text-green border border-green/30' : 'glass-card text-text-secondary'}`}>Reset</button>
                      <button onClick={() => updateAutoBetSetting('onLoss', 'action', 'increase')} className={`flex-1 py-1.5 rounded text-[10px] font-bold ${autoBetSettings.onLoss.action === 'increase' ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>Increase by</button>
                    </div>
                    {autoBetSettings.onLoss.action !== 'reset' && (
                      <div className="flex items-center gap-1 mt-1">
                        <input type="number" value={autoBetSettings.onLoss.value} onChange={e => updateAutoBetSetting('onLoss', 'value', Number(e.target.value))} className="flex-1 bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0" max="500" />
                        <span className="text-xs text-text-secondary font-bold">%</span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <div className="text-[9px] text-text-secondary mb-0.5">Stop on Win</div>
                      <input type="number" value={autoBetSettings.stopOnWin} onChange={e => setAutoBetSettings(prev => ({ ...prev, stopOnWin: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" placeholder="∞" min="0" />
                    </div>
                    <div>
                      <div className="text-[9px] text-text-secondary mb-0.5">Stop on Loss</div>
                      <input type="number" value={autoBetSettings.stopOnLoss} onChange={e => setAutoBetSettings(prev => ({ ...prev, stopOnLoss: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" placeholder="∞" min="0" />
                    </div>
                  </div>

                  <div>
                    <div className="text-[9px] text-text-secondary mb-0.5">Max Bet</div>
                    <input type="number" value={autoBetSettings.maxBet} onChange={e => setAutoBetSettings(prev => ({ ...prev, maxBet: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0.01" />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ADVANCED TAB */}
        {controlTab === 'advanced' && (
          <div className="space-y-2 glass-card p-3">
            <div className="text-xs font-bold text-gold mb-2">ADVANCED SETTINGS</div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-text-secondary">Provably Fair</span>
              <span className="text-[10px] text-cyan font-mono">{serverSeedHash}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-text-secondary">House Edge</span>
              <span className="text-xs text-gold font-bold">1%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-text-secondary">Round #</span>
              <span className="text-xs text-cyan font-orbitron">{roundNumber}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-text-secondary">Next Bet</span>
              <span className="text-xs text-gold font-orbitron">{autoBetStats.currentBet.toFixed(2)} TMC</span>
            </div>
          </div>
        )}
      </div>

      {/* Round Bets */}
      <div className="glass-card p-3">
        <div className="text-[10px] text-text-secondary uppercase tracking-wider mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />Round Bets
        </div>
        <div className="space-y-1.5 max-h-32 overflow-y-auto">
          {roundBets.length === 0 && <div className="text-xs text-text-muted text-center py-2">No bets this round</div>}
          {roundBets.map((bet, i) => (
            <div key={i} className="flex items-center justify-between text-xs glass-card p-2">
              <span className="text-text-secondary">👤 {bet.username}</span>
              <span className="font-orbitron text-gold">{bet.amount} TMC</span>
              <span className={bet.status === 'cashed' ? 'text-green' : bet.status === 'crashed' ? 'text-red' : 'text-cyan'}>
                {bet.status === 'cashed' ? '✅ +' + (bet.amount * bet.multiplier - bet.amount).toFixed(2) : bet.status === 'crashed' ? '💥 -' + bet.amount : '● ACTIVE'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DiceGame({ user, setUser, addTransaction }) {
  const [target, setTarget] = useState(50);
  const [direction, setDirection] = useState('over');
  const [betAmount, setBetAmount] = useState(50);
  const [rolling, setRolling] = useState(false);
  const [result, setResult] = useState(null);
  const [showResult, setShowResult] = useState(false);

  const [controlTab, setControlTab] = useState('manual');
  const [autoBet, setAutoBet] = useState(false);
  const [autoRounds, setAutoRounds] = useState(0);
  const [autoRolled, setAutoRolled] = useState(0);
  const [showAutoSettings, setShowAutoSettings] = useState(false);
  const [autoSettings, setAutoSettings] = useState({
    onWin: { action: 'reset', value: 0 },
    onLoss: { action: 'increase', value: 100 },
    stopOnWin: 0, stopOnLoss: 0, maxBet: 10000,
  });
  const [autoStats, setAutoStats] = useState({ wins: 0, losses: 0, currentBet: 50 });
  const autoTimerRef = useRef(null);

  const winChance = direction === 'over' ? 100 - target : target - 1;
  const multiplier = parseFloat(((100 / winChance) * 0.99).toFixed(2));
  const potentialWin = (betAmount * multiplier).toFixed(2);

  const calculateNextBet = (lastResult) => {
    let nextBet = autoStats.currentBet;
    if (lastResult === 'win') {
      if (autoSettings.onWin.action === 'reset') nextBet = betAmount;
      else if (autoSettings.onWin.action === 'increase') nextBet = autoStats.currentBet * (1 + autoSettings.onWin.value / 100);
    } else {
      if (autoSettings.onLoss.action === 'reset') nextBet = betAmount;
      else if (autoSettings.onLoss.action === 'increase') nextBet = autoStats.currentBet * (1 + autoSettings.onLoss.value / 100);
    }
    return Math.max(0.01, Math.min(autoSettings.maxBet, nextBet));
  };

  const executeRoll = () => {
    if (user.tmcBalance < betAmount) { setAutoBet(false); alert('Insufficient balance!'); return; }
    setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance - betAmount }));
    setRolling(true); setShowResult(false); setResult(null);

    setTimeout(() => {
      const roll = Math.floor(Math.random() * 100) + 1;
      const isWin = direction === 'over' ? roll > target : roll < target;
      const winAmount = isWin ? betAmount * multiplier : 0;
      setResult({ roll, isWin, winAmount, multiplier });
      setRolling(false); setShowResult(true);

      if (isWin) {
        setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance + winAmount, totalWon: prev.totalWon + winAmount - betAmount }));
        addTransaction({ type: 'bet_credit', amount: winAmount, direction: 'credit', note: `Dice ${roll} ${direction} ${target} @ ${multiplier}×` });
        const nextBet = calculateNextBet('win');
        setAutoStats(prev => ({ ...prev, wins: prev.wins + 1, currentBet: nextBet }));
      } else {
        setUser(prev => ({ ...prev, totalLost: prev.totalLost + betAmount }));
        addTransaction({ type: 'bet_debit', amount: betAmount, direction: 'debit', note: `Dice ${roll} ${direction} ${target}` });
        const nextBet = calculateNextBet('loss');
        setAutoStats(prev => ({ ...prev, losses: prev.losses + 1, currentBet: nextBet }));
      }

      setAutoRolled(prev => prev + 1);
    }, 700);
  };

  const handleRoll = () => {
    if (rolling || betAmount < 0.01) return;
    executeRoll();
  };

  const toggleAuto = () => {
    if (autoBet) {
      setAutoBet(false);
      clearInterval(autoTimerRef.current);
    } else {
      setAutoBet(true);
      setAutoRolled(0);
      setAutoStats({ wins: 0, losses: 0, currentBet: betAmount });
      executeRoll();
      autoTimerRef.current = setInterval(() => {
        setAutoRolled(prev => {
          if (autoRounds > 0 && prev >= autoRounds) {
            setAutoBet(false);
            clearInterval(autoTimerRef.current);
            return prev;
          }
          if (!rolling) executeRoll();
          return prev + 1;
        });
      }, 1200);
    }
  };

  useEffect(() => { return () => clearInterval(autoTimerRef.current); }, []);

  const halfBet = () => setBetAmount(prev => Math.max(0.01, prev / 2));
  const doubleBet = () => setBetAmount(prev => prev * 2);

  return (
    <div className="space-y-3">
      <div className={`glass-card p-6 text-center ${showResult && result?.isWin ? 'win-flash' : showResult && !result?.isWin ? 'lose-flash' : ''}`}>
        <div className={`font-orbitron text-5xl font-bold mb-1 ${rolling ? 'number-roll' : ''} ${showResult ? (result?.isWin ? 'text-green' : 'text-red') : 'text-gold'}`}>
          {rolling ? '—' : showResult ? result?.roll : '—'}
        </div>
        {showResult && <div className={`text-xs font-bold ${result?.isWin ? 'text-green' : 'text-red'}`}>{result?.isWin ? 'WIN' : 'LOSE'} · {result?.roll} {direction} {target}</div>}
        {!showResult && !rolling && <div className="text-xs text-text-secondary">Set target and roll</div>}
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="glass-card p-2 text-center"><div className="text-[9px] text-text-secondary">Win Chance</div><div className="font-orbitron text-sm text-cyan">{winChance}%</div></div>
        <div className="glass-card p-2 text-center"><div className="text-[9px] text-text-secondary">Multiplier</div><div className="font-orbitron text-sm text-gold">{multiplier}×</div></div>
        <div className="glass-card p-2 text-center"><div className="text-[9px] text-text-secondary">Potential</div><div className="font-orbitron text-sm text-green">{potentialWin}</div></div>
      </div>

      <div className="glass-card p-3">
        <div className="flex items-center justify-between mb-1"><span className="text-xs text-text-secondary">Target</span><span className="font-orbitron text-gold text-sm">{target}</span></div>
        <input type="range" min="1" max="95" value={target} onChange={e => setTarget(Number(e.target.value))} className="w-full h-1.5 bg-surface rounded-lg appearance-none cursor-pointer accent-gold" />
        <div className="flex justify-between text-[9px] text-text-muted mt-1"><span>1 → 99%</span><span>95 → 5%</span></div>
      </div>

      <div className="flex gap-2">
        <button onClick={() => setDirection('over')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${direction === 'over' ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}>ROLL OVER</button>
        <button onClick={() => setDirection('under')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${direction === 'under' ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}>ROLL UNDER</button>
      </div>

      <div className="flex justify-center">
        <div className="flex gap-1 p-0.5 bg-surface rounded-lg w-full">
          {['manual', 'auto'].map(tab => (
            <button key={tab} onClick={() => setControlTab(tab)} className={`flex-1 py-2 rounded-md text-xs font-bold font-sora transition-all text-center ${controlTab === tab ? 'bg-gold/20 text-gold border border-gold/30' : 'text-text-secondary'}`}>
              {tab === 'manual' ? 'Manual' : (
                <span className="flex items-center justify-center gap-1">
                  Auto {autoBet && <span className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="glass-card p-2">
        <div className="text-[9px] text-text-secondary uppercase tracking-wider mb-1">Amount</div>
        <div className="flex items-center gap-1">
          <span className="text-gold text-xs">◎</span>
          <input type="number" value={betAmount} onChange={e => { const num = parseFloat(e.target.value); if (!isNaN(num) && num >= 0) setBetAmount(num); }} className="flex-1 bg-transparent font-orbitron text-sm outline-none min-w-0" min="0.01" step="0.01" />
          <div className="flex gap-0.5 flex-shrink-0">
            <button onClick={halfBet} className="px-1.5 py-0.5 bg-surface rounded text-[9px] font-bold text-text-secondary hover:text-gold">1/2</button>
            <button onClick={doubleBet} className="px-1.5 py-0.5 bg-surface rounded text-[9px] font-bold text-text-secondary hover:text-gold">2×</button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-1.5">
        {[1, 10, 100, 1000].map(n => (
          <button key={n} onClick={() => setBetAmount(n)} className="py-1.5 rounded-lg text-xs font-bold font-orbitron glass-card text-text-secondary hover:text-gold hover:border-gold/30 transition-all">
            {n >= 1000 ? (n/1000).toFixed(1) + 'k' : n}
          </button>
        ))}
      </div>

      {controlTab === 'manual' && (
        <button onClick={handleRoll} disabled={rolling || betAmount < 0.01} className="w-full bg-green hover:bg-green/80 text-[#050508] py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 disabled:opacity-50">
          {rolling ? 'ROLLING...' : betAmount < 0.01 ? 'MIN 0.01 TMC' : `ROLL ${betAmount.toFixed(2)} TMC`}
        </button>
      )}

      {controlTab === 'auto' && (
        <div className="space-y-2">
          <div className="glass-card p-2">
            <div className="text-[9px] text-text-secondary mb-1">Rounds</div>
            <div className="flex gap-1">
              <button onClick={() => setAutoRounds(0)} className={`flex-1 py-1.5 rounded text-xs font-bold ${autoRounds === 0 ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}><Infinity className="w-3 h-3 mx-auto" /></button>
              {[10, 50, 100].map(n => (
                <button key={n} onClick={() => setAutoRounds(n)} className={`flex-1 py-1.5 rounded text-xs font-bold ${autoRounds === n ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}>{n}</button>
              ))}
            </div>
          </div>

          <button onClick={toggleAuto} className={`w-full py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 ${autoBet ? 'bg-red/20 text-red border border-red/30' : 'bg-green hover:bg-green/80 text-[#050508]'}`}>
            {autoBet ? `STOP (${autoStats.wins}W/${autoStats.losses}L)` : 'START AUTO ROLL'}
          </button>

          <div className="glass-card p-2">
            <button onClick={() => setShowAutoSettings(!showAutoSettings)} className="w-full flex items-center justify-between text-xs font-bold text-text-secondary">
              <span>Advanced Options</span>
              {showAutoSettings ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {showAutoSettings && (
              <div className="space-y-3 mt-2 pt-2 border-t border-border">
                <div className="space-y-1">
                  <div className="text-[9px] text-text-secondary">On Win</div>
                  <div className="flex gap-1">
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onWin: { action: 'reset', value: 0 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onWin.action === 'reset' ? 'bg-green/20 text-green border border-green/30' : 'glass-card text-text-secondary'}`}>Reset</button>
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onWin: { action: 'increase', value: 50 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onWin.action === 'increase' ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>Increase by</button>
                  </div>
                  {autoSettings.onWin.action !== 'reset' && (
                    <div className="flex items-center gap-1 mt-1">
                      <input type="number" value={autoSettings.onWin.value} onChange={e => setAutoSettings(prev => ({ ...prev, onWin: { ...prev.onWin, value: Number(e.target.value) } }))} className="flex-1 bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0" max="500" />
                      <span className="text-xs text-text-secondary font-bold">%</span>
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="text-[9px] text-text-secondary">On Loss</div>
                  <div className="flex gap-1">
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onLoss: { action: 'reset', value: 0 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onLoss.action === 'reset' ? 'bg-green/20 text-green border border-green/30' : 'glass-card text-text-secondary'}`}>Reset</button>
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onLoss: { action: 'increase', value: 100 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onLoss.action === 'increase' ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>Increase by</button>
                  </div>
                  {autoSettings.onLoss.action !== 'reset' && (
                    <div className="flex items-center gap-1 mt-1">
                      <input type="number" value={autoSettings.onLoss.value} onChange={e => setAutoSettings(prev => ({ ...prev, onLoss: { ...prev.onLoss, value: Number(e.target.value) } }))} className="flex-1 bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0" max="500" />
                      <span className="text-xs text-text-secondary font-bold">%</span>
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div><div className="text-[9px] text-text-secondary mb-0.5">Stop on Win</div><input type="number" value={autoSettings.stopOnWin} onChange={e => setAutoSettings(prev => ({ ...prev, stopOnWin: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" placeholder="∞" min="0" /></div>
                  <div><div className="text-[9px] text-text-secondary mb-0.5">Stop on Loss</div><input type="number" value={autoSettings.stopOnLoss} onChange={e => setAutoSettings(prev => ({ ...prev, stopOnLoss: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" placeholder="∞" min="0" /></div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function LimboGame({ user, setUser, addTransaction }) {
  const [target, setTarget] = useState(2.0);
  const [betAmount, setBetAmount] = useState(50);
  const [playing, setPlaying] = useState(false);
  const [result, setResult] = useState(null);
  const [showResult, setShowResult] = useState(false);

  const [controlTab, setControlTab] = useState('manual');
  const [autoBet, setAutoBet] = useState(false);
  const [autoRounds, setAutoRounds] = useState(0);
  const [autoRolled, setAutoRolled] = useState(0);
  const [showAutoSettings, setShowAutoSettings] = useState(false);
  const [autoSettings, setAutoSettings] = useState({
    onWin: { action: 'reset', value: 0 },
    onLoss: { action: 'increase', value: 100 },
    stopOnWin: 0, stopOnLoss: 0, maxBet: 10000,
  });
  const [autoStats, setAutoStats] = useState({ wins: 0, losses: 0, currentBet: 50 });
  const autoTimerRef = useRef(null);

  const winChance = parseFloat((99 / target).toFixed(2));
  const potentialWin = (betAmount * target).toFixed(2);

  const calculateNextBet = (lastResult) => {
    let nextBet = autoStats.currentBet;
    if (lastResult === 'win') {
      if (autoSettings.onWin.action === 'reset') nextBet = betAmount;
      else if (autoSettings.onWin.action === 'increase') nextBet = autoStats.currentBet * (1 + autoSettings.onWin.value / 100);
    } else {
      if (autoSettings.onLoss.action === 'reset') nextBet = betAmount;
      else if (autoSettings.onLoss.action === 'increase') nextBet = autoStats.currentBet * (1 + autoSettings.onLoss.value / 100);
    }
    return Math.max(0.01, Math.min(autoSettings.maxBet, nextBet));
  };

  const executePlay = () => {
    if (user.tmcBalance < betAmount) { setAutoBet(false); alert('Insufficient balance!'); return; }
    setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance - betAmount }));
    setPlaying(true); setShowResult(false); setResult(null);

    setTimeout(() => {
      const float = Math.random();
      const resultMult = float < 0.01 ? 1.00 : Math.max(1.01, parseFloat((0.99 / (1 - float)).toFixed(2)));
      const isWin = resultMult >= target;
      const winAmount = isWin ? betAmount * target : 0;
      setResult({ resultMult, isWin, winAmount });
      setPlaying(false); setShowResult(true);

      if (isWin) {
        setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance + winAmount, totalWon: prev.totalWon + winAmount - betAmount }));
        addTransaction({ type: 'bet_credit', amount: winAmount, direction: 'credit', note: `Limbo ${resultMult.toFixed(2)}× ≥ ${target}×` });
        const nextBet = calculateNextBet('win');
        setAutoStats(prev => ({ ...prev, wins: prev.wins + 1, currentBet: nextBet }));
      } else {
        setUser(prev => ({ ...prev, totalLost: prev.totalLost + betAmount }));
        addTransaction({ type: 'bet_debit', amount: betAmount, direction: 'debit', note: `Limbo ${resultMult.toFixed(2)}× < ${target}×` });
        const nextBet = calculateNextBet('loss');
        setAutoStats(prev => ({ ...prev, losses: prev.losses + 1, currentBet: nextBet }));
      }

      setAutoRolled(prev => prev + 1);
    }, 800);
  };

  const handlePlay = () => {
    if (playing || betAmount < 0.01) return;
    executePlay();
  };

  const toggleAuto = () => {
    if (autoBet) {
      setAutoBet(false);
      clearInterval(autoTimerRef.current);
    } else {
      setAutoBet(true);
      setAutoRolled(0);
      setAutoStats({ wins: 0, losses: 0, currentBet: betAmount });
      executePlay();
      autoTimerRef.current = setInterval(() => {
        setAutoRolled(prev => {
          if (autoRounds > 0 && prev >= autoRounds) {
            setAutoBet(false);
            clearInterval(autoTimerRef.current);
            return prev;
          }
          if (!playing) executePlay();
          return prev + 1;
        });
      }, 1300);
    }
  };

  useEffect(() => { return () => clearInterval(autoTimerRef.current); }, []);

  const halfBet = () => setBetAmount(prev => Math.max(0.01, prev / 2));
  const doubleBet = () => setBetAmount(prev => prev * 2);

  return (
    <div className="space-y-3">
      <div className={`glass-card p-6 text-center ${showResult && result?.isWin ? 'win-flash' : showResult && !result?.isWin ? 'lose-flash' : ''}`}>
        <div className={`font-orbitron text-5xl font-bold mb-1 transition-all duration-300 ${playing ? 'scale-110 text-gold animate-pulse' : ''} ${showResult ? (result?.isWin ? 'text-green' : 'text-red') : 'text-gold'}`}>
          {playing ? '⏳' : showResult ? `${result?.resultMult.toFixed(2)}×` : '—'}
        </div>
        {showResult && <div className={`text-xs font-bold ${result?.isWin ? 'text-green' : 'text-red'}`}>{result?.resultMult.toFixed(2)}× {result?.isWin ? '≥' : '<'} {target}× {result?.isWin ? 'WIN' : 'LOSE'}</div>}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="glass-card p-2 text-center"><div className="text-[9px] text-text-secondary">Win Chance</div><div className="font-orbitron text-sm text-cyan">{winChance.toFixed(2)}%</div></div>
        <div className="glass-card p-2 text-center"><div className="text-[9px] text-text-secondary">Potential Win</div><div className="font-orbitron text-sm text-green">{potentialWin} TMC</div></div>
      </div>

      <div className="glass-card p-3">
        <div className="text-xs text-text-secondary mb-2">Target Multiplier</div>
        <div className="flex items-center gap-2 mb-2">
          <input type="number" value={target} onChange={e => { const num = parseFloat(e.target.value); if (!isNaN(num) && num >= 1.01) setTarget(num); }} step="0.01" min="1.01" className="flex-1 bg-surface border border-border rounded-lg px-3 py-2 font-orbitron text-lg outline-none focus:border-gold/50 min-w-0" />
          <span className="text-gold font-bold flex-shrink-0">×</span>
        </div>
        <div className="grid grid-cols-6 gap-1.5">
          {[1.5, 2, 5, 10, 50, 100].map(n => (
            <button key={n} onClick={() => setTarget(n)} className={`py-1.5 rounded text-xs font-bold font-orbitron ${target === n ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>{n}×</button>
          ))}
        </div>
      </div>

      <div className="flex justify-center">
        <div className="flex gap-1 p-0.5 bg-surface rounded-lg w-full">
          {['manual', 'auto'].map(tab => (
            <button key={tab} onClick={() => setControlTab(tab)} className={`flex-1 py-2 rounded-md text-xs font-bold font-sora transition-all text-center ${controlTab === tab ? 'bg-gold/20 text-gold border border-gold/30' : 'text-text-secondary'}`}>
              {tab === 'manual' ? 'Manual' : (
                <span className="flex items-center justify-center gap-1">
                  Auto {autoBet && <span className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="glass-card p-2">
        <div className="text-[9px] text-text-secondary uppercase tracking-wider mb-1">Amount</div>
        <div className="flex items-center gap-1">
          <span className="text-gold text-xs">◎</span>
          <input type="number" value={betAmount} onChange={e => { const num = parseFloat(e.target.value); if (!isNaN(num) && num >= 0) setBetAmount(num); }} className="flex-1 bg-transparent font-orbitron text-sm outline-none min-w-0" min="0.01" step="0.01" />
          <div className="flex gap-0.5 flex-shrink-0">
            <button onClick={halfBet} className="px-1.5 py-0.5 bg-surface rounded text-[9px] font-bold text-text-secondary hover:text-gold">1/2</button>
            <button onClick={doubleBet} className="px-1.5 py-0.5 bg-surface rounded text-[9px] font-bold text-text-secondary hover:text-gold">2×</button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-1.5">
        {[1, 10, 100, 1000].map(n => (
          <button key={n} onClick={() => setBetAmount(n)} className="py-1.5 rounded-lg text-xs font-bold font-orbitron glass-card text-text-secondary hover:text-gold hover:border-gold/30 transition-all">
            {n >= 1000 ? (n/1000).toFixed(1) + 'k' : n}
          </button>
        ))}
      </div>

      {controlTab === 'manual' && (
        <button onClick={handlePlay} disabled={playing || betAmount < 0.01} className="w-full bg-green hover:bg-green/80 text-[#050508] py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 disabled:opacity-50">
          {playing ? 'PLAYING...' : betAmount < 0.01 ? 'MIN 0.01 TMC' : `PLAY ${betAmount.toFixed(2)} TMC`}
        </button>
      )}

      {controlTab === 'auto' && (
        <div className="space-y-2">
          <div className="glass-card p-2">
            <div className="text-[9px] text-text-secondary mb-1">Rounds</div>
            <div className="flex gap-1">
              <button onClick={() => setAutoRounds(0)} className={`flex-1 py-1.5 rounded text-xs font-bold ${autoRounds === 0 ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}><Infinity className="w-3 h-3 mx-auto" /></button>
              {[10, 50, 100].map(n => (
                <button key={n} onClick={() => setAutoRounds(n)} className={`flex-1 py-1.5 rounded text-xs font-bold ${autoRounds === n ? 'bg-cyan/20 text-cyan border border-cyan/30' : 'glass-card text-text-secondary'}`}>{n}</button>
              ))}
            </div>
          </div>

          <button onClick={toggleAuto} className={`w-full py-3.5 rounded-xl text-sm font-bold font-sora transition-all active:scale-95 ${autoBet ? 'bg-red/20 text-red border border-red/30' : 'bg-green hover:bg-green/80 text-[#050508]'}`}>
            {autoBet ? `STOP (${autoStats.wins}W/${autoStats.losses}L)` : 'START AUTO PLAY'}
          </button>

          <div className="glass-card p-2">
            <button onClick={() => setShowAutoSettings(!showAutoSettings)} className="w-full flex items-center justify-between text-xs font-bold text-text-secondary">
              <span>Advanced Options</span>
              {showAutoSettings ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {showAutoSettings && (
              <div className="space-y-3 mt-2 pt-2 border-t border-border">
                <div className="space-y-1">
                  <div className="text-[9px] text-text-secondary">On Win</div>
                  <div className="flex gap-1">
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onWin: { action: 'reset', value: 0 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onWin.action === 'reset' ? 'bg-green/20 text-green border border-green/30' : 'glass-card text-text-secondary'}`}>Reset</button>
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onWin: { action: 'increase', value: 50 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onWin.action === 'increase' ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>Increase by</button>
                  </div>
                  {autoSettings.onWin.action !== 'reset' && (
                    <div className="flex items-center gap-1 mt-1">
                      <input type="number" value={autoSettings.onWin.value} onChange={e => setAutoSettings(prev => ({ ...prev, onWin: { ...prev.onWin, value: Number(e.target.value) } }))} className="flex-1 bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0" max="500" />
                      <span className="text-xs text-text-secondary font-bold">%</span>
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="text-[9px] text-text-secondary">On Loss</div>
                  <div className="flex gap-1">
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onLoss: { action: 'reset', value: 0 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onLoss.action === 'reset' ? 'bg-green/20 text-green border border-green/30' : 'glass-card text-text-secondary'}`}>Reset</button>
                    <button onClick={() => setAutoSettings(prev => ({ ...prev, onLoss: { action: 'increase', value: 100 } }))} className={`flex-1 py-1 rounded text-[9px] font-bold ${autoSettings.onLoss.action === 'increase' ? 'bg-gold/20 text-gold border border-gold/30' : 'glass-card text-text-secondary'}`}>Increase by</button>
                  </div>
                  {autoSettings.onLoss.action !== 'reset' && (
                    <div className="flex items-center gap-1 mt-1">
                      <input type="number" value={autoSettings.onLoss.value} onChange={e => setAutoSettings(prev => ({ ...prev, onLoss: { ...prev.onLoss, value: Number(e.target.value) } }))} className="flex-1 bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" min="0" max="500" />
                      <span className="text-xs text-text-secondary font-bold">%</span>
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div><div className="text-[9px] text-text-secondary mb-0.5">Stop on Win</div><input type="number" value={autoSettings.stopOnWin} onChange={e => setAutoSettings(prev => ({ ...prev, stopOnWin: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" placeholder="∞" min="0" /></div>
                  <div><div className="text-[9px] text-text-secondary mb-0.5">Stop on Loss</div><input type="number" value={autoSettings.stopOnLoss} onChange={e => setAutoSettings(prev => ({ ...prev, stopOnLoss: Number(e.target.value) }))} className="w-full bg-surface rounded px-2 py-1 text-xs font-orbitron outline-none" placeholder="∞" min="0" /></div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function WalletTab({ user, setUser, transactions, addTransaction }) {
  const [swapDirection, setSwapDirection] = useState('buy');
  const [swapAmount, setSwapAmount] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const rate = 1000, fee = swapDirection === 'sell' ? 0.02 : 0;

  const calculateReceive = () => {
    const amount = parseFloat(swapAmount) || 0;
    return swapDirection === 'buy' ? amount * rate : (amount * (1 - fee)) / rate;
  };

  const handleSwap = () => {
    if (swapDirection === 'sell' && parseFloat(swapAmount) > user.tmcBalance) { alert('Insufficient TMC!'); return; }
    if (swapDirection === 'sell' && parseFloat(swapAmount) < 500) { alert('Min withdrawal: 500 TMC'); return; }
    setShowConfirm(true);
  };

  const confirmSwap = () => {
    const amount = parseFloat(swapAmount), receive = calculateReceive();
    if (swapDirection === 'buy') { setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance + receive })); addTransaction({ type: 'deposit', amount: receive, direction: 'credit', ton_amount: amount, note: 'TON → TMC' }); }
    else { setUser(prev => ({ ...prev, tmcBalance: prev.tmcBalance - amount })); addTransaction({ type: 'withdrawal', amount, direction: 'debit', ton_amount: receive, note: 'TMC → TON (2% fee)' }); }
    setSwapAmount(''); setShowConfirm(false);
  };

  const connectWallet = () => setUser(prev => ({ ...prev, tonWalletAddress: 'UQDr...xK3f' }));
  const getTxIcon = (type) => type.includes('win') || type === 'bet_credit' || type === 'mining_passive' || type === 'mining_daily' || type === 'deposit' ? '✅' : type === 'withdrawal' ? '⏳' : '💥';
  const getTxColor = (type) => type.includes('win') || type === 'bet_credit' || type === 'mining_passive' || type === 'mining_daily' || type === 'deposit' ? 'text-green' : type === 'withdrawal' ? 'text-gold' : 'text-red';

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="glass-card p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="font-orbitron text-sm text-text-secondary">TON WALLET</span>
          {user.tonWalletAddress ? <span className="text-xs text-cyan font-mono bg-cyan/10 px-2 py-1 rounded">{user.tonWalletAddress} ✓</span> : <button onClick={connectWallet} className="btn-gold px-3 py-1.5 text-xs">Connect</button>}
        </div>
        <div className="text-center py-4">
          <div className="font-orbitron text-3xl font-bold text-gold">{formatTMC(user.tmcBalance)}</div>
          <div className="text-xs text-text-secondary mt-1">≈ {formatTON(user.tmcBalance / rate)} TON</div>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-2">
          <div className="text-center"><div className="text-[10px] text-text-secondary">MINED</div><div className="font-orbitron text-xs text-cyan">{formatTMC(user.totalMined)}</div></div>
          <div className="text-center"><div className="text-[10px] text-text-secondary">WON</div><div className="font-orbitron text-xs text-green">{formatTMC(user.totalWon)}</div></div>
          <div className="text-center"><div className="text-[10px] text-text-secondary">DEPOSIT</div><div className="font-orbitron text-xs text-gold">0.00</div></div>
        </div>
      </div>

      <div className="glass-card p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="font-orbitron text-sm text-text-secondary">SWAP</span>
          <div className="flex gap-1 bg-surface rounded-lg p-0.5">
            <button onClick={() => setSwapDirection('buy')} className={`px-3 py-1 rounded text-xs font-bold ${swapDirection === 'buy' ? 'bg-gold/20 text-gold' : 'text-text-secondary'}`}>BUY</button>
            <button onClick={() => setSwapDirection('sell')} className={`px-3 py-1 rounded text-xs font-bold ${swapDirection === 'sell' ? 'bg-red/20 text-red' : 'text-text-secondary'}`}>SELL</button>
          </div>
        </div>
        <div className="glass-card p-3 mb-2">
          <div className="text-[10px] text-text-secondary mb-1">YOU SEND</div>
          <div className="flex items-center justify-between">
            <input type="number" value={swapAmount} onChange={e => setSwapAmount(e.target.value)} placeholder="0.00" className="bg-transparent font-orbitron text-xl outline-none w-32 min-w-0" />
            <span className="font-bold text-sm flex-shrink-0">{swapDirection === 'buy' ? 'TON' : 'TMC'}</span>
          </div>
          <div className="text-[10px] text-text-muted mt-1">Balance: {swapDirection === 'buy' ? '3.45 TON' : `${formatTMC(user.tmcBalance)} TMC`}</div>
        </div>
        <div className="flex justify-center -my-2 relative z-10">
          <button onClick={() => setSwapDirection(s => s === 'buy' ? 'sell' : 'buy')} className="bg-[#050508] border border-border rounded-full p-1.5 hover:border-gold/50 transition-colors"><ArrowUpDown className="w-4 h-4 text-gold" /></button>
        </div>
        <div className="glass-card p-3 mt-2">
          <div className="text-[10px] text-text-secondary mb-1">YOU RECEIVE</div>
          <div className="font-orbitron text-xl text-gold">{formatTMC(calculateReceive())}</div>
          <div className="text-[10px] text-text-muted mt-1">1 TON = 1,000 TMC {swapDirection === 'sell' && '(2% fee)'}</div>
        </div>
        <button onClick={handleSwap} className="w-full btn-gold py-3 mt-3 text-sm">CONFIRM SWAP → {swapDirection === 'buy' ? 'BUY TMC' : 'WITHDRAW'}</button>
      </div>

      <div className="space-y-2">
        <h3 className="font-orbitron text-xs text-text-secondary uppercase tracking-wider px-1">Recent Transactions</h3>
        {transactions.map(tx => (
          <div key={tx.id} className="glass-card p-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg">{getTxIcon(tx.type)}</span>
              <div><div className="text-xs font-sora font-medium capitalize">{tx.type.replace(/_/g, ' ')}</div><div className="text-[10px] text-text-muted">{tx.note}</div></div>
            </div>
            <div className={`font-orbitron text-sm font-bold ${getTxColor(tx.type)}`}>{tx.direction === 'credit' ? '+' : '-'}{formatTMC(tx.amount)}</div>
          </div>
        ))}
      </div>

      {showConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <div className="flex items-center gap-2 text-gold mb-4"><AlertTriangle className="w-5 h-5" /><span className="font-orbitron font-bold">Confirm {swapDirection === 'buy' ? 'Purchase' : 'Withdrawal'}</span></div>
            <p className="text-sm text-text-secondary mb-4">Are you sure? This cannot be undone.</p>
            <div className="glass-card p-3 mb-4 text-center"><div className="text-xs text-text-secondary">You will receive</div><div className="font-orbitron text-xl text-gold">{formatTMC(calculateReceive())} TMC</div></div>
            <div className="flex gap-2"><button onClick={() => setShowConfirm(false)} className="flex-1 btn-ghost py-3 text-sm">Cancel</button><button onClick={confirmSwap} className="flex-1 btn-gold py-3 text-sm">Confirm</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

function RanksTab({ user }) {
  const [rankTab, setRankTab] = useState('miners');
  const leaders = {
    miners: [{ name: 'CryptoKing', amount: 450000, league: 'Legend' }, { name: 'TonWhale', amount: 234000, league: 'Diamond' }, { name: 'MinerPro', amount: 89000, league: 'Gold' }, { name: 'Satoshi', amount: 45000, league: 'Gold' }, { name: 'BlockDigger', amount: 12000, league: 'Silver' }, { name: 'Newbie', amount: 500, league: 'Bronze' }],
    bettors: [{ name: 'HighRoller', amount: 2500000, league: 'Legend' }, { name: 'CasinoPro', amount: 1200000, league: 'Diamond' }, { name: 'LuckyStrike', amount: 890000, league: 'Gold' }, { name: 'BetMaster', amount: 450000, league: 'Gold' }, { name: 'RiskTaker', amount: 120000, league: 'Silver' }, { name: 'SmallBets', amount: 5000, league: 'Bronze' }],
    winners: [{ name: 'LuckyStrike', amount: 890000, league: 'Gold' }, { name: 'CryptoKing', amount: 670000, league: 'Legend' }, { name: 'TonWhale', amount: 450000, league: 'Diamond' }, { name: 'Winner', amount: 230000, league: 'Gold' }, { name: 'ProfitMaker', amount: 89000, league: 'Silver' }, { name: 'EvenSteven', amount: 100, league: 'Bronze' }],
  };
  const getLeagueIcon = (league) => ({ 'Legend': '👑', 'Diamond': '💎', 'Gold': '🥇', 'Silver': '🥈', 'Bronze': '🥉' }[league] || '🥉');
  const getLeagueColor = (league) => ({ 'Legend': '#C084FC', 'Diamond': '#00E5FF', 'Gold': '#FFB800', 'Silver': '#94A3B8', 'Bronze': '#CD7F32' }[league] || '#CD7F32');

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="glass-card-gold p-4">
        <div className="font-orbitron text-sm text-gold mb-3">Your Referral Link</div>
        <div className="glass-card p-2 flex items-center gap-2 mb-3">
          <code className="text-xs text-cyan flex-1 truncate">t.me/TonMineBot?start={user.referralCode}</code>
          <button className="p-1.5 hover:bg-white/5 rounded"><Copy className="w-4 h-4 text-text-secondary" /></button>
          <button className="p-1.5 hover:bg-white/5 rounded"><Share2 className="w-4 h-4 text-text-secondary" /></button>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="glass-card p-2 text-center"><div className="text-[10px] text-text-secondary">Total Earned</div><div className="font-orbitron text-sm text-gold">+1,247 TMC</div></div>
          <div className="glass-card p-2 text-center"><div className="text-[10px] text-text-secondary">Direct Friends</div><div className="font-orbitron text-sm text-cyan">23</div></div>
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-xs"><span className="text-text-secondary">Tier 1 (Direct)</span><span className="text-gold font-bold">25%</span></div>
          <div className="flex justify-between text-xs"><span className="text-text-secondary">Tier 2 (Level 2)</span><span className="text-cyan font-bold">10%</span></div>
          <div className="flex justify-between text-xs"><span className="text-text-secondary">Tier 3 (Level 3)</span><span className="text-purple font-bold">5%</span></div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex gap-1 p-1 bg-surface rounded-xl">
          {[{ id: 'miners', label: 'Top Miners', icon: '⛏️' }, { id: 'bettors', label: 'Top Bettors', icon: '🎰' }, { id: 'winners', label: 'Top Winners', icon: '🏆' }].map(tab => (
            <button key={tab.id} onClick={() => setRankTab(tab.id)} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${rankTab === tab.id ? 'bg-gold/20 text-gold border border-gold/30' : 'text-text-secondary'}`}><span className="mr-1">{tab.icon}</span>{tab.label}</button>
          ))}
        </div>
        <div className="space-y-2">
          {leaders[rankTab].map((leader, i) => (
            <div key={i} className={`glass-card p-3 flex items-center justify-between ${leader.name === user.username ? 'border-gold/30 bg-gold/5' : ''}`}>
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-orbitron ${i === 0 ? 'bg-gold/20 text-gold' : i === 1 ? 'bg-gray-400/20 text-gray-300' : i === 2 ? 'bg-orange-700/20 text-orange-400' : 'text-text-muted'}`}>{i + 1}</div>
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getLeagueIcon(leader.league)}</span>
                  <div><div className="text-sm font-sora font-medium">{leader.name}</div><div className="text-[10px]" style={{ color: getLeagueColor(leader.league) }}>{leader.league}</div></div>
                </div>
              </div>
              <div className="font-orbitron text-sm text-gold">{formatTMC(leader.amount)}</div>
            </div>
          ))}
        </div>
        <div className="glass-card-gold p-3 flex items-center justify-between sticky bottom-2">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-gold/20 text-gold flex items-center justify-center text-xs font-bold font-orbitron">?</div>
            <div className="flex items-center gap-2">
              <span className="text-lg">🥉</span>
              <div><div className="text-sm font-sora font-medium text-gold">{user.username} (You)</div><div className="text-[10px] text-text-secondary">Bronze</div></div>
            </div>
          </div>
          <div className="font-orbitron text-sm text-gold">{formatTMC(user.totalMined)}</div>
        </div>
      </div>
    </div>
  );
}
